import java.io.*;
import java.nio.file.*;
import java.util.*; 
import static java.nio.file.StandardOpenOption.*;



public class UserAccount{
Scanner s = new Scanner(System.in); 
	String filename = "e:\\account.txt"; 
	public UserAccount(){ 
		try{ 
			System.out.println("-------------------------------");
			System.out.println("1. Create New Account");
			System.out.println("2. Login with existing account");
			System.out.println("-------------------------------");
			System.out.print("Enter Your Choice: ");
			String choice = s.nextLine();
			if(choice.equals("1")){
				createaccount();
			}
		}catch(Exception ex){ 

		}
	} 
	
	public void createaccount(){ 
		try{
			Path path = Paths.get(filename.toString());
			OutputStream output = new BufferedOutputStream(Files.newOutputStream(path, APPEND));
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output));
			System.out.print("Enter your username: ");
			String username = s.nextLine();
			System.out.print("Enter password: ");
			String password = s.nextLine();

			writer.write(username + "," + password);
			writer.newLine();
			System.out.println("Account has been successfully created!");
			writer.close();
			output.close();

			new UserAccount();
		}catch(Exception ex){
			System.out.print(ex.getMessage());
		}
	} 

	public static void main(String[]args){
		new UserAccount();
	}

}








